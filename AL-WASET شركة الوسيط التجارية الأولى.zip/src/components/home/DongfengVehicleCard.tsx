/**
 * DongfengVehicleCard.tsx
 * Presentational card component for displaying a single Dongfeng vehicle
 * with image, key details, and navigation to a dedicated detail page.
 */

import type { ReactNode } from 'react'
import { Link } from 'react-router'

/**
 * DongfengVehicleCardProps
 * Props for configuring a Dongfeng vehicle card.
 */
interface DongfengVehicleCardProps {
  /** Vehicle name or model designation. */
  name: string
  /** Short segment or category label (e.g. Pickup, Light truck, SUV). */
  segment: string
  /** Concise description of the vehicle's primary role or positioning. */
  description: string
  /** Bullet-style highlights such as payload, engine, warranty, etc. */
  highlights: ReactNode[]
  /** Image URL to visually represent the vehicle. */
  imageSrc: string
  /** Route path for the detail page of this vehicle. */
  href: string
}

/**
 * DongfengVehicleCard
 * Displays a Dongfeng vehicle with an image, name, segment label, and bullet highlights.
 * The entire card acts as a link that navigates to the vehicle's dedicated detail page.
 */
export function DongfengVehicleCard({
  name,
  segment,
  description,
  highlights,
  imageSrc,
  href,
}: DongfengVehicleCardProps) {
  return (
    <Link
      to={href}
      className="block focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500 focus-visible:ring-offset-2 focus-visible:ring-offset-slate-50"
      aria-label={`${name} details`}
    >
      <article className="flex h-full flex-col overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm transition hover:-translate-y-1 hover:shadow-md">
        <div className="relative h-40 w-full overflow-hidden bg-slate-100 sm:h-44">
          <img
            src={imageSrc}
            alt={name}
            className="h-full w-full object-cover transition duration-300 ease-out group-hover:scale-105"
          />
        </div>
        <div className="flex flex-1 flex-col p-4">
          <div className="flex items-baseline justify-between gap-2">
            <h3 className="text-sm font-semibold tracking-tight text-slate-900">
              {name}
            </h3>
            <span className="rounded-full bg-sky-50 px-2 py-0.5 text-[0.65rem] font-semibold uppercase tracking-[0.18em] text-sky-700">
              {segment}
            </span>
          </div>
          <p className="mt-2 text-xs leading-relaxed text-slate-600">
            {description}
          </p>
          <ul className="mt-3 space-y-1.5 text-xs text-slate-700">
            {highlights.map((item, index) => (
              // Using index is acceptable here because the list is static and order does not change.
              <li key={index} className="flex gap-2">
                <span className="mt-[6px] inline-flex h-1.5 w-1.5 rounded-full bg-sky-600" />
                <span>{item}</span>
              </li>
            ))}
          </ul>
          <p className="mt-3 text-[0.7rem] font-medium text-sky-700">
            View full vehicle details →
          </p>
        </div>
      </article>
    </Link>
  )
}