/**
 * SiteFooter.tsx
 * Application-wide footer for AL-WASET First Commercial Company.
 */

/**
 * SiteFooter
 * Renders the main site footer with company info and quick links.
 */
export function SiteFooter() {
  const currentYear = new Date().getFullYear()

  return (
    <footer className="mt-12 border-t border-slate-200 bg-slate-50">
      <div className="mx-auto flex max-w-6xl flex-col gap-6 px-4 py-8 md:flex-row md:items-center md:justify-between">
        <div>
          <p className="text-sm font-semibold text-slate-800">
            AL-WASET First Commercial Company
          </p>
          <p className="mt-1 text-xs text-slate-500">
            Reliable partner in trading, distribution, and commercial services.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-4 text-xs text-slate-500">
          <span>&copy; {currentYear} AL-WASET. All rights reserved.</span>
          <span className="hidden h-3 w-px bg-slate-300 md:inline-block" />
          <span>Built for clarity, trust, and long-term partnerships.</span>
        </div>
      </div>
    </footer>
  )
}
