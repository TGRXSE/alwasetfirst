/**
 * Contact.tsx
 * Contact page for AL-WASET First Commercial Company with animated form,
 * company details, and a placeholder for an embedded location map.
 */

import type { FormEvent } from 'react'
import { motion } from 'motion/react'
import { AnimatedSection } from '../components/common/AnimatedSection'

/**
 * ContactFormFieldProps
 * Props for a reusable contact form input field.
 */
interface ContactFormFieldProps {
  /** Input id and name */
  id: string
  /** Visible field label */
  label: string
  /** HTML input type */
  type?: string
  /** Whether the field is required */
  required?: boolean
  /** Optional placeholder text */
  placeholder?: string
}

/**
 * ContactFormField
 * Reusable labeled input field for the contact form.
 */
function ContactFormField({
  id,
  label,
  type = 'text',
  required,
  placeholder,
}: ContactFormFieldProps) {
  return (
    <div className="space-y-1.5">
      <label htmlFor={id} className="text-xs font-medium text-slate-800">
        {label}
      </label>
      <input
        id={id}
        name={id}
        type={type}
        required={required}
        placeholder={placeholder}
        className="w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 shadow-sm outline-none ring-sky-500/0 transition focus:ring-2 focus:ring-sky-500"
      />
    </div>
  )
}

/**
 * Contact
 * Provides a contact form, company contact information, and a location map area.
 */
export default function Contact() {
  /**
   * Handles contact form submission by preventing default behavior.
   * In a real implementation, this would send data to a backend service.
   * @param event - Form submission event.
   */
  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
  }

  return (
    <motion.div
      className="space-y-10 md:space-y-12"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.45, ease: 'easeOut' }}
    >
      {/* Header copy */}
      <AnimatedSection className="space-y-3">
        <p className="text-xs font-semibold uppercase tracking-[0.22em] text-sky-600">
          Contact AL-WASET
        </p>
        <h1 className="text-2xl font-semibold tracking-tight text-slate-900 md:text-3xl">
          We are ready to discuss your commercial requirements.
        </h1>
        <p className="max-w-3xl text-sm leading-relaxed text-slate-600 md:text-base">
          Share a brief overview of your needs and the AL-WASET team will respond with
          structured next steps. For time-sensitive requests, please reach out by phone.
        </p>
      </AnimatedSection>

      {/* Main content: form + details / map */}
      <AnimatedSection
        className="grid gap-8 md:grid-cols-[1.4fr,1fr] md:items-start"
        delay={0.05}
      >
        {/* Contact form */}
        <motion.form
          onSubmit={handleSubmit}
          className="space-y-4 rounded-xl border border-slate-200 bg-white p-5 shadow-sm md:p-6"
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.55, ease: 'easeOut' }}
        >
          <div className="grid gap-4 md:grid-cols-2">
            <ContactFormField
              id="name"
              label="Full name"
              type="text"
              required
              placeholder="Your name"
            />
            <ContactFormField
              id="email"
              label="Work email"
              type="email"
              required
              placeholder="you@company.com"
            />
          </div>

          <ContactFormField
            id="subject"
            label="Subject"
            type="text"
            required
            placeholder="Brief summary of your inquiry"
          />

          <div className="space-y-1.5">
            <label
              htmlFor="message"
              className="text-xs font-medium text-slate-800"
            >
              Message
            </label>
            <textarea
              id="message"
              name="message"
              required
              rows={5}
              className="w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 shadow-sm outline-none ring-sky-500/0 transition focus:ring-2 focus:ring-sky-500"
              placeholder="Share details about your trading, distribution, or commercial service requirements."
            />
          </div>

          <motion.button
            type="submit"
            className="inline-flex w-full items-center justify-center rounded-md bg-sky-700 px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-sky-800 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500 md:w-auto"
            whileHover={{ y: -2 }}
            whileTap={{ y: 0 }}
            transition={{ type: 'spring', stiffness: 260, damping: 20 }}
          >
            Submit inquiry
          </motion.button>

          <p className="text-[0.7rem] text-slate-500">
            By submitting this form, you consent to AL-WASET contacting you regarding
            your inquiry. Your information will be handled confidentially.
          </p>
        </motion.form>

        {/* Company details and map placeholder */}
        <motion.aside
          className="space-y-5"
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.55, ease: 'easeOut', delay: 0.05 }}
        >
          <div className="rounded-xl border border-slate-200 bg-slate-50 p-4 text-xs text-slate-700 shadow-sm md:text-sm">
            <h2 className="text-sm font-semibold text-slate-900">
              Company details
            </h2>
            <div className="mt-3 space-y-3">
              <div>
                <p className="text-[0.7rem] font-semibold uppercase tracking-[0.18em] text-slate-500">
                  Address
                </p>
                <p className="mt-1">
                  AL-WASET First Commercial Company
                  <br />
                  [Street name / Business district]
                  <br />
                  [City], Libya
                </p>
              </div>

              <div>
                <p className="text-[0.7rem] font-semibold uppercase tracking-[0.18em] text-slate-500">
                  Phone
                </p>
                <p className="mt-1">+[Country code] [Contact number]</p>
              </div>

              <div>
                <p className="text-[0.7rem] font-semibold uppercase tracking-[0.18em] text-slate-500">
                  Email
                </p>
                <p className="mt-1">contact@alwaset-commercial.com</p>
              </div>

              <div>
                <p className="text-[0.7rem] font-semibold uppercase tracking-[0.18em] text-slate-500">
                  Office hours
                </p>
                <p className="mt-1">
                  Sunday – Thursday, 9:00 – 17:00 (local time)
                </p>
              </div>
            </div>
          </div>

          {/* Map placeholder area */}
          <div className="rounded-xl border border-dashed border-sky-200 bg-sky-50/40 p-4 text-xs text-sky-900 shadow-inner md:text-sm">
            <p className="text-[0.7rem] font-semibold uppercase tracking-[0.18em] text-sky-700">
              Location map
            </p>
            <p className="mt-2 text-slate-700">
              Map integration placeholder. You can embed Google Maps or another
              mapping service here to show the exact office location.
            </p>
            <div className="mt-3 h-40 rounded-lg bg-white/70 ring-1 ring-sky-100" />
          </div>
        </motion.aside>
      </AnimatedSection>
    </motion.div>
  )
}
