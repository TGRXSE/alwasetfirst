/**
 * Products.tsx
 * Products &amp; Services page for AL-WASET First Commercial Company.
 */

import { motion } from 'motion/react'
import { AnimatedSection } from '../components/common/AnimatedSection'

/**
 * Products
 * Presents a structured grid of AL-WASET's main products and services.
 */
export default function Products() {
  const offerings = [
    {
      title: 'Import &amp; Export Solutions',
      summary:
        'End-to-end coordination for international sourcing and cross-border trade.',
      details: [
        'Supplier and manufacturer liaison',
        'Commercial documentation guidance',
        'Compliance-aware coordination',
      ],
    },
    {
      title: 'Wholesale Distribution Programs',
      summary:
        'Structured distribution frameworks tailored to regional channels.',
      details: [
        'Channel and territory definition',
        'Inventory and replenishment planning',
        'Performance tracking and reporting',
      ],
    },
    {
      title: 'Logistics Management Support',
      summary:
        'Alignment between logistics partners, warehousing, and end customers.',
      details: [
        'Shipment tracking and exception follow-up',
        'Vendor and carrier coordination',
        'Service-level monitoring',
      ],
    },
    {
      title: 'Market Entry &amp; Expansion Advisory',
      summary:
        'Commercial insight for brands entering or expanding within regional markets.',
      details: [
        'Market mapping and channel analysis',
        'Go-to-market and pricing guidance',
        'Introduction to key ecosystem partners',
      ],
    },
    {
      title: 'Procurement &amp; Sourcing Support',
      summary:
        'Support for institutional and commercial buyers seeking dependable supply.',
      details: [
        'Vendor shortlisting and evaluation',
        'Structured RFQ and negotiation support',
        'Ongoing supplier performance review',
      ],
    },
    {
      title: 'After-Sales &amp; Relationship Management',
      summary:
        'Post-transaction coordination to sustain long-term commercial relationships.',
      details: [
        'Query and issue resolution support',
        'Performance review sessions',
        'Continuous improvement initiatives',
      ],
    },
  ]

  return (
    <motion.div
      className="space-y-8 md:space-y-10"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.45, ease: 'easeOut' }}
    >
      <AnimatedSection className="space-y-3">
        <p className="text-xs font-semibold uppercase tracking-[0.22em] text-sky-600">
          Products &amp; Services
        </p>
        <h1 className="text-2xl font-semibold tracking-tight text-slate-900 md:text-3xl">
          Structured commercial offerings for dependable growth.
        </h1>
        <p className="max-w-3xl text-sm leading-relaxed text-slate-600 md:text-base">
          AL-WASET First Commercial Company provides a portfolio of services
          that cover the full commercial lifecycle. Each offering can be
          provided independently or combined into an integrated partnership
          model.
        </p>
      </AnimatedSection>

      <AnimatedSection className="grid gap-5 md:grid-cols-2" delay={0.05}>
        {offerings.map((offering, index) => (
          <motion.article
            key={offering.title}
            className="flex flex-col rounded-xl border border-slate-200 bg-white p-5 shadow-sm transition hover:shadow-md"
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.25 }}
            transition={{
              duration: 0.5,
              ease: 'easeOut',
              delay: 0.05 + index * 0.03,
            }}
            whileHover={{ y: -4 }}
            whileTap={{ y: 0 }}
          >
            <h2 className="text-sm font-semibold text-slate-900 md:text-base">
              {offering.title}
            </h2>
            <p className="mt-2 text-xs text-slate-600 md:text-sm">
              {offering.summary}
            </p>
            <ul className="mt-3 space-y-1.5 text-xs text-slate-600 md:text-sm">
              {offering.details.map((detail) => (
                <li key={detail}>• {detail}</li>
              ))}
            </ul>
          </motion.article>
        ))}
      </AnimatedSection>

      <AnimatedSection
        className="rounded-xl border border-sky-100 bg-sky-50 p-5 text-xs text-slate-700 shadow-sm md:text-sm"
        delay={0.1}
      >
        <h2 className="text-sm font-semibold text-slate-900 md:text-base">
          Tailored engagement models
        </h2>
        <p className="mt-2">
          Engagements with AL-WASET are structured to reflect the specific
          needs of each partner: from single-lane trading arrangements to fully
          integrated trading, distribution, and support programs.
        </p>
        <p className="mt-2">
          Partners may start with a focused scope and expand services in line
          with market response and performance.
        </p>
      </AnimatedSection>
    </motion.div>
  )
}
