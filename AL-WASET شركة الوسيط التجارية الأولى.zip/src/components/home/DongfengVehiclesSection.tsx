/**
 * DongfengVehiclesSection.tsx
 * Section showcasing a grid of highlighted Dongfeng vehicles with images
 * and navigation to dedicated detail pages for each vehicle.
 */

import { AnimatedSection } from '../common/AnimatedSection'
import { DongfengVehicleCard } from './DongfengVehicleCard'
import { dongfengVehicles } from '../../data/dongfengVehicles'

/**
 * DongfengVehiclesSection
 * Renders a titled section with multiple DongfengVehicleCard items in a responsive grid.
 */
export function DongfengVehiclesSection() {
  return (
    <AnimatedSection
      id="dongfeng-vehicles"
      delay={0.14}
      className="rounded-xl border border-slate-200 bg-slate-50 px-4 py-6 md:px-6 md:py-7"
    >
      <div className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
        <div>
          <h2 className="text-xl font-semibold tracking-tight text-slate-900 md:text-2xl">
            Dongfeng vehicles for commercial needs
          </h2>
          <p className="mt-1 text-sm text-slate-600 md:max-w-2xl">
            A focused selection of Dongfeng models commonly used in trading, logistics,
            and corporate operations. Click on any vehicle card to open a dedicated
            view with more detailed information about how it can support your
            business requirements.
          </p>
        </div>
        <p className="text-xs font-medium uppercase tracking-[0.18em] text-slate-500">
          Vehicle overview
        </p>
      </div>

      <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {dongfengVehicles.map((vehicle) => (
          <DongfengVehicleCard
            key={vehicle.slug}
            name={vehicle.name}
            segment={vehicle.segment}
            description={vehicle.shortDescription}
            highlights={vehicle.highlights}
            imageSrc={vehicle.heroImage}
            href={`/vehicles/${vehicle.slug}`}
          />
        ))}
      </div>
    </AnimatedSection>
  )
}