/**
 * About.tsx
 * About page describing AL-WASET First Commercial Company's background, mission, and strengths.
 */

import { motion } from 'motion/react'
import { AnimatedSection } from '../components/common/AnimatedSection'

/**
 * About
 * Presents company history, mission, and key strengths in a clear layout.
 */
export default function About() {
  return (
    <motion.div
      className="space-y-10 md:space-y-14"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.45, ease: 'easeOut' }}
    >
      <AnimatedSection className="grid gap-8 md:grid-cols-[1.2fr,1fr] md:items-start">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.22em] text-sky-600">
            About AL-WASET
          </p>
          <h1 className="mt-3 text-2xl font-semibold tracking-tight text-slate-900 md:text-3xl">
            Building dependable commercial bridges between markets.
          </h1>
          <p className="mt-4 text-sm leading-relaxed text-slate-600 md:text-base">
            AL-WASET First Commercial Company was founded with a clear goal:
            to provide structured, reliable, and transparent commercial
            services that connect suppliers, distributors, and institutions
            across regional and international markets.
          </p>
          <p className="mt-3 text-sm leading-relaxed text-slate-600 md:text-base">
            Over time, the company has grown by focusing on discipline,
            compliance, and long-term relationships. Today, AL-WASET supports
            partners across trading, distribution, logistics coordination, and
            commercial representation services.
          </p>
        </div>

        <motion.div
          className="overflow-hidden rounded-xl border border-slate-200 bg-slate-900/95 text-white shadow-md"
          initial={{ opacity: 0, x: 32 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, amount: 0.4 }}
          transition={{ duration: 0.6, ease: 'easeOut', delay: 0.1 }}
        >
          <img
            src="https://pub-cdn.sider.ai/u/U0Z6H6YZE20/web-coder/697e357acabc5f0ad8729716/resource/f25b09b8-020f-430b-a47d-32eac9eba159.jpg"
            alt="Professional commercial team in a meeting"
            className="h-40 w-full object-cover opacity-75"
          />
          <div className="space-y-3 p-5 text-xs text-slate-100/90 md:text-sm">
            <p className="text-[0.7rem] font-semibold uppercase tracking-[0.22em] text-sky-200">
              Our approach
            </p>
            <p>
              Each partnership begins with a detailed understanding of
              objectives, constraints, and risk tolerance. Agreements are
              designed to be clear, measurable, and practical.
            </p>
            <p>
              From there, AL-WASET coordinates trading, logistics, and
              commercial communication to keep all stakeholders aligned.
            </p>
          </div>
        </motion.div>
      </AnimatedSection>

      <AnimatedSection className="grid gap-8 md:grid-cols-2" delay={0.1}>
        <motion.div
          className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm md:p-6"
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.55, ease: 'easeOut' }}
        >
          <h2 className="text-lg font-semibold tracking-tight text-slate-900">
            Mission
          </h2>
          <p className="mt-2 text-sm text-slate-600">
            To be a trusted commercial partner that delivers reliable trading,
            distribution, and support services through disciplined operations,
            transparent communication, and strong governance.
          </p>
          <ul className="mt-4 space-y-2 text-sm text-slate-600">
            <li>• Enable predictable and sustainable supply flows.</li>
            <li>• Simplify complex trading and logistics arrangements.</li>
            <li>
              • Support partners in entering and expanding within regional
              markets.
            </li>
          </ul>
        </motion.div>

        <motion.div
          className="rounded-xl border border-slate-200 bg-slate-50 p-5 shadow-sm md:p-6"
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.55, ease: 'easeOut', delay: 0.05 }}
        >
          <h2 className="text-lg font-semibold tracking-tight text-slate-900">
            Key strengths
          </h2>
          <ul className="mt-3 space-y-2 text-sm text-slate-700">
            <li>
              <span className="font-semibold text-slate-900">
                Consistent reliability:
              </span>{' '}
              Emphasis on timelines, documentation, and operational discipline.
            </li>
            <li>
              <span className="font-semibold text-slate-900">
                Market understanding:
              </span>{' '}
              Practical knowledge of regional requirements and partner
              expectations.
            </li>
            <li>
              <span className="font-semibold text-slate-900">
                Transparent communication:
              </span>{' '}
              Regular updates and clearly defined processes throughout each
              engagement.
            </li>
            <li>
              <span className="font-semibold text-slate-900">
                Partner-centric mindset:
              </span>{' '}
              Focus on long-term outcomes over short-term transactions.
            </li>
          </ul>
        </motion.div>
      </AnimatedSection>
    </motion.div>
  )
}
