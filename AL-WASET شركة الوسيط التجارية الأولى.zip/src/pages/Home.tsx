/**
 * Home.tsx
 * Landing page for AL-WASET First Commercial Company.
 */

import { motion } from 'motion/react'
import { AnimatedSection } from '../components/common/AnimatedSection'
import { DongfengVehiclesSection } from '../components/home/DongfengVehiclesSection'

/**
 * Home
 * Displays hero section, core business activities, Dongfeng factory intro,
 * Dongfeng vehicle highlights, and unique value propositions.
 */
export default function Home() {
  return (
    <motion.div
      className="space-y-12 md:space-y-16"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.45, ease: 'easeOut' }}
    >
      {/* Hero Section */}
      <AnimatedSection className="grid gap-8 md:grid-cols-2 md:items-center">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.22em] text-sky-600">
            AL-WASET First Commercial Company
          </p>
          <h1 className="mt-3 text-3xl font-semibold tracking-tight text-slate-900 md:text-4xl lg:text-5xl">
            Reliable trading and commercial services for ambitious businesses.
          </h1>
          <p className="mt-4 text-sm leading-relaxed text-slate-600 md:text-base">
            AL-WASET First Commercial Company connects suppliers, distributors,
            and enterprises through structured trading, distribution, and
            commercial support services designed for long-term growth and
            reliability.
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <motion.a
              href="#core-activities"
              whileHover={{ y: -2 }}
              whileTap={{ y: 0 }}
              transition={{ type: 'spring', stiffness: 260, damping: 20 }}
              className="inline-flex items-center justify-center rounded-md bg-sky-700 px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-sky-800 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500"
            >
              Explore core activities
            </motion.a>
            <motion.a
              href="#value"
              whileHover={{ y: -2 }}
              whileTap={{ y: 0 }}
              transition={{ type: 'spring', stiffness: 260, damping: 20 }}
              className="inline-flex items-center justify-center rounded-md border border-slate-300 bg-white px-4 py-2.5 text-sm font-semibold text-slate-800 shadow-sm transition hover:bg-slate-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500"
            >
              Why partners choose AL-WASET
            </motion.a>
          </div>
          <dl className="mt-6 grid grid-cols-2 gap-4 text-xs text-slate-600 sm:text-sm md:max-w-md">
            <div>
              <dt className="font-semibold text-slate-800">Core focus</dt>
              <dd className="mt-1">
                Trading, distribution, logistics coordination, and commercial
                representation.
              </dd>
            </div>
            <div>
              <dt className="font-semibold text-slate-800">Partnership style</dt>
              <dd className="mt-1">
                Transparent, data-driven, and tailored to regional requirements.
              </dd>
            </div>
          </dl>
        </div>

        <motion.div
          className="relative h-56 overflow-hidden rounded-xl border border-slate-200 bg-slate-900/95 text-white shadow-md sm:h-64 md:h-72"
          initial={{ opacity: 0, x: 32 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6, ease: 'easeOut', delay: 0.1 }}
        >
          <img
            src="https://pub-cdn.sider.ai/u/U0Z6H6YZE20/web-coder/697e357acabc5f0ad8729716/resource/cba1af4c-d3c2-48ac-ab4d-d6bf5d0968e1.jpg"
            alt="Modern commercial skyline"
            className="absolute inset-0 h-full w-full object-cover opacity-65"
          />
          <div className="relative flex h-full flex-col justify-between p-5">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.22em] text-sky-200">
                Trusted commercial partner
              </p>
              <p className="mt-2 text-lg font-semibold md:text-xl">
                Bridging regional markets with dependable supply and services.
              </p>
            </div>
            <div className="space-y-2 text-xs text-slate-100/90 md:text-sm">
              <p className="flex items-center gap-2">
                <span className="inline-flex h-2 w-2 rounded-full bg-emerald-400" />
                Structured sourcing and distribution across key sectors.
              </p>
              <p className="flex items-center gap-2">
                <span className="inline-flex h-2 w-2 rounded-full bg-sky-400" />
                Clear communication, transparent terms, and consistent follow-up.
              </p>
              <p className="flex items-center gap-2">
                <span className="inline-flex h-2 w-2 rounded-full bg-amber-300" />
                Long-term partnerships supported by experienced commercial teams.
              </p>
            </div>
          </div>
        </motion.div>
      </AnimatedSection>

      {/* Core Business Activities */}
      <AnimatedSection
        id="core-activities"
        delay={0.1}
        className="rounded-xl border border-slate-200 bg-slate-50 px-4 py-6 md:px-6 md:py-7"
      >
        <div className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
          <div>
            <h2 className="text-xl font-semibold tracking-tight text-slate-900 md:text-2xl">
              Core business activities
            </h2>
            <p className="mt-1 text-sm text-slate-600 md:max-w-2xl">
              AL-WASET First Commercial Company operates across the full
              trading cycle—from sourcing and import/export to distribution and
              after-sales coordination—ensuring reliability at each step.
            </p>
          </div>
          <p className="text-xs font-medium uppercase tracking-[0.18em] text-slate-500">
            Trading • Distribution • Services
          </p>
        </div>

        <div className="mt-6 grid gap-4 md:grid-cols-3">
          <motion.article
            className="flex flex-col rounded-lg bg-white p-4 shadow-sm ring-1 ring-slate-200"
            whileHover={{ y: -4 }}
            whileTap={{ y: 0 }}
            transition={{ type: 'spring', stiffness: 260, damping: 20 }}
          >
            <h3 className="text-sm font-semibold text-slate-900">
              Trading &amp; Distribution
            </h3>
            <p className="mt-2 text-xs text-slate-600">
              Coordinated sourcing, import, and distribution for key commercial
              goods with a focus on predictable delivery and clear terms.
            </p>
            <ul className="mt-3 space-y-1.5 text-xs text-slate-600">
              <li>• Supplier and manufacturer coordination</li>
              <li>• Import / export documentation support</li>
              <li>• Structured distribution programs</li>
            </ul>
          </motion.article>

          <motion.article
            className="flex flex-col rounded-lg bg-white p-4 shadow-sm ring-1 ring-slate-200"
            whileHover={{ y: -4 }}
            whileTap={{ y: 0 }}
            transition={{
              type: 'spring',
              stiffness: 260,
              damping: 20,
              delay: 0.02,
            }}
          >
            <h3 className="text-sm font-semibold text-slate-900">
              Logistics &amp; Supply Coordination
            </h3>
            <p className="mt-2 text-xs text-slate-600">
              Alignment of logistics partners, warehousing, and delivery
              schedules to safeguard continuity of supply.
            </p>
            <ul className="mt-3 space-y-1.5 text-xs text-slate-600">
              <li>• Coordination with logistics providers</li>
              <li>• Inventory and replenishment planning</li>
              <li>• Risk and delay mitigation support</li>
            </ul>
          </motion.article>

          <motion.article
            className="flex flex-col rounded-lg bg-white p-4 shadow-sm ring-1 ring-slate-200"
            whileHover={{ y: -4 }}
            whileTap={{ y: 0 }}
            transition={{
              type: 'spring',
              stiffness: 260,
              damping: 20,
              delay: 0.04,
            }}
          >
            <h3 className="text-sm font-semibold text-slate-900">
              Commercial Representation &amp; Support
            </h3>
            <p className="mt-2 text-xs text-slate-600">
              Structured commercial representation for brands and partners
              entering or expanding in regional markets.
            </p>
            <ul className="mt-3 space-y-1.5 text-xs text-slate-600">
              <li>• Market access and channel insight</li>
              <li>• Local relationship management</li>
              <li>• Post-sale and service coordination</li>
            </ul>
          </motion.article>
        </div>
      </AnimatedSection>

      {/* Dongfeng Factory Introduction &amp; Video */}
      <AnimatedSection
        id="dongfeng-factory"
        delay={0.12}
        className="grid gap-6 rounded-xl border border-slate-200 bg-white px-4 py-6 md:grid-cols-[1.2fr,1fr] md:items-center md:px-6 md:py-7"
      >
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.22em] text-sky-600">
            Dongfeng Factory
          </p>
          <h2 className="mt-2 text-xl font-semibold tracking-tight text-slate-900 md:text-2xl">
            Strong manufacturing foundation with Dongfeng.
          </h2>
          <p className="mt-3 text-sm text-slate-600 md:max-w-xl">
            Dongfeng&apos;s modern manufacturing facilities combine automated
            production lines, stringent quality control, and continuous
            technical improvement. Through collaboration with Dongfeng,
            AL-WASET can connect partners to reliable vehicle and component
            supply backed by a proven industrial base.
          </p>
          <p className="mt-3 text-xs text-slate-500 md:text-sm">
            The short video highlights key stages in the factory environment,
            illustrating how Dongfeng manages efficiency, safety, and quality
            across its production processes.
          </p>
        </div>

        <div className="overflow-hidden rounded-xl border border-slate-200 bg-slate-900/90 shadow-sm">
          <div className="relative aspect-video w-full">
            <iframe
              className="absolute inset-0 h-full w-full"
              src="https://www.youtube.com/embed/udL3D8lcHSk?rel=0"
              title="Dongfeng factory overview video"
              loading="lazy"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
              allowFullScreen
            />
          </div>
        </div>
      </AnimatedSection>

      {/* Dongfeng Vehicle Highlights */}
      <DongfengVehiclesSection />

      {/* Unique Value Proposition */}
      <AnimatedSection id="value" delay={0.15}>
        <div className="grid gap-6 md:grid-cols-[1.2fr,1fr] md:items-start">
          <div>
            <h2 className="text-xl font-semibold tracking-tight text-slate-900 md:text-2xl">
              A partner built on reliability and clarity.
            </h2>
            <p className="mt-2 text-sm text-slate-600 md:max-w-xl">
              AL-WASET First Commercial Company focuses on long-term,
              relationship-based partnerships. Every engagement is built around
              clear communication, disciplined operations, and measured growth.
            </p>
            <div className="mt-4 grid gap-4 sm:grid-cols-2">
              <motion.div
                className="rounded-lg border border-slate-200 bg-white p-4"
                whileHover={{ y: -3 }}
                whileTap={{ y: 0 }}
                transition={{ type: 'spring', stiffness: 260, damping: 20 }}
              >
                <p className="text-xs font-semibold uppercase tracking-[0.18em] text-sky-600">
                  Structured process
                </p>
                <p className="mt-2 text-sm font-semibold text-slate-900">
                  Disciplined trading and service frameworks.
                </p>
                <p className="mt-2 text-xs text-slate-600">
                  From onboarding to ongoing reporting, partners receive
                  consistent updates and a clear understanding of performance.
                </p>
              </motion.div>
              <motion.div
                className="rounded-lg border border-slate-200 bg-white p-4"
                whileHover={{ y: -3 }}
                whileTap={{ y: 0 }}
                transition={{
                  type: 'spring',
                  stiffness: 260,
                  damping: 20,
                  delay: 0.02,
                }}
              >
                <p className="text-xs font-semibold uppercase tracking-[0.18em] text-sky-600">
                  Regional insight
                </p>
                <p className="mt-2 text-sm font-semibold text-slate-900">
                  Local understanding with global standards.
                </p>
                <p className="mt-2 text-xs text-slate-600">
                  Experience across regional markets allows AL-WASET to align
                  global expectations with local realities.
                </p>
              </motion.div>
            </div>
          </div>

          <motion.div
            className="rounded-xl border border-sky-100 bg-sky-50 p-4 text-xs text-slate-700 shadow-sm sm:text-sm"
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.55, ease: 'easeOut', delay: 0.1 }}
          >
            <p className="text-[0.7rem] font-semibold uppercase tracking-[0.22em] text-sky-700">
              Key advantages
            </p>
            <ul className="mt-3 space-y-2">
              <li className="flex gap-2">
                <span className="mt-[6px] inline-flex h-1.5 w-1.5 rounded-full bg-sky-600" />
                <span>
                  Clear commercial structures that protect both suppliers and
                  buyers.
                </span>
              </li>
              <li className="flex gap-2">
                <span className="mt-[6px] inline-flex h-1.5 w-1.5 rounded-full bg-sky-600" />
                <span>
                  Emphasis on on-time delivery and transparent logistics
                  coordination.
                </span>
              </li>
              <li className="flex gap-2">
                <span className="mt-[6px] inline-flex h-1.5 w-1.5 rounded-full bg-sky-600" />
                <span>
                  Dedicated relationship management for long-term commercial
                  growth.
                </span>
              </li>
            </ul>
          </motion.div>
        </div>
      </AnimatedSection>
    </motion.div>
  )
}
