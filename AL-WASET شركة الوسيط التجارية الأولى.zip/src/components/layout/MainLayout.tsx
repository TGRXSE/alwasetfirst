/**
 * MainLayout.tsx
 * Shared layout wrapper with header, main content area, and footer.
 */

import type { ReactNode } from 'react'
import { SiteHeader } from './SiteHeader'
import { SiteFooter } from './SiteFooter'

/**
 * MainLayout
 * Wraps page content with consistent header, constrained content width, and footer.
 */
export function MainLayout(props: { children: ReactNode }) {
  const { children } = props

  return (
    <div className="flex min-h-screen flex-col bg-white text-slate-900">
      <SiteHeader />
      <main className="flex-1">
        <div className="mx-auto max-w-6xl px-4 py-8 md:py-10">{children}</div>
      </main>
      <SiteFooter />
    </div>
  )
}
