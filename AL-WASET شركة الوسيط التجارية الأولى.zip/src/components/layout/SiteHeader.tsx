/**
 * SiteHeader.tsx
 * Application-wide top navigation bar for AL-WASET First Commercial Company.
 */

import { useState } from 'react'
import { Link, useLocation } from 'react-router'

/**
 * SiteHeader
 * Renders the main site header with logo and navigation links.
 */
export function SiteHeader() {
  const [isMobileOpen, setIsMobileOpen] = useState(false)
  const location = useLocation()

  /**
   * Determines if a given path is the current active route.
   * @param path - Route path to compare.
   */
  const isActive = (path: string) => location.pathname === path

  return (
    <header className="border-b border-slate-200 bg-white/90 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3 md:py-4">
        <Link to="/" className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-md bg-sky-700 text-white">
            <span className="text-lg font-semibold">AW</span>
          </div>
          <div className="flex flex-col leading-tight">
            <span className="text-sm font-semibold tracking-wide text-slate-900 md:text-base">
              AL-WASET First Commercial Company
            </span>
            <span className="text-xs text-slate-500 md:text-[0.7rem]">
              Trading • Distribution • Commercial Services
            </span>
          </div>
        </Link>

        <nav className="hidden items-center gap-6 text-sm font-medium text-slate-700 md:flex">
          <NavLink to="/" label="Home" active={isActive('/')} />
          <NavLink to="/about" label="About Us" active={isActive('/about')} />
          <NavLink
            to="/products"
            label="Products &amp; Services"
            active={isActive('/products')}
          />
          <NavLink
            to="/contact"
            label="Contact Us"
            active={isActive('/contact')}
          />
        </nav>

        <button
          type="button"
          className="inline-flex items-center justify-center rounded-md border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-medium text-slate-700 shadow-sm hover:bg-slate-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500 md:hidden"
          aria-label="Toggle navigation menu"
          onClick={() => setIsMobileOpen((open) => !open)}
        >
          <span className="mr-1">Menu</span>
          <span className="inline-block h-[1px] w-4 bg-slate-700" />
        </button>
      </div>

      {isMobileOpen && (
        <div className="border-t border-slate-200 bg-white md:hidden">
          <nav className="mx-auto flex max-w-6xl flex-col px-4 py-2 text-sm font-medium text-slate-700">
            <MobileNavLink
              to="/"
              label="Home"
              active={isActive('/')}
              onClick={() => setIsMobileOpen(false)}
            />
            <MobileNavLink
              to="/about"
              label="About Us"
              active={isActive('/about')}
              onClick={() => setIsMobileOpen(false)}
            />
            <MobileNavLink
              to="/products"
              label="Products &amp; Services"
              active={isActive('/products')}
              onClick={() => setIsMobileOpen(false)}
            />
            <MobileNavLink
              to="/contact"
              label="Contact Us"
              active={isActive('/contact')}
              onClick={() => setIsMobileOpen(false)}
            />
          </nav>
        </div>
      )}
    </header>
  )
}

/**
 * NavLink
 * Desktop navigation link with active state styling.
 */
function NavLink(props: { to: string; label: string; active: boolean }) {
  const { to, label, active } = props
  return (
    <Link
      to={to}
      className={`border-b-2 pb-1 transition-colors ${
        active
          ? 'border-sky-600 text-sky-700'
          : 'border-transparent text-slate-700 hover:border-slate-300 hover:text-slate-900'
      }`}
    >
      {label}
    </Link>
  )
}

/**
 * MobileNavLink
 * Mobile navigation link with full-width tappable area.
 */
function MobileNavLink(props: {
  to: string
  label: string
  active: boolean
  onClick: () => void
}) {
  const { to, label, active, onClick } = props
  return (
    <Link
      to={to}
      onClick={onClick}
      className={`block rounded-md px-3 py-2 ${
        active
          ? 'bg-sky-50 text-sky-700'
          : 'text-slate-700 hover:bg-slate-50 hover:text-slate-900'
      }`}
    >
      {label}
    </Link>
  )
}
