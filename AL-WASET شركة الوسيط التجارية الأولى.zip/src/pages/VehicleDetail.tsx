/**
 * VehicleDetail.tsx
 * Dynamic detail page for a single Dongfeng vehicle, selected via a URL slug.
 */

import { motion } from 'motion/react'
import { useNavigate, useParams } from 'react-router'
import { AnimatedSection } from '../components/common/AnimatedSection'
import {
  getDongfengVehicleBySlug,
  type DongfengVehicle,
} from '../data/dongfengVehicles'

/**
 * VehicleDetail
 * Reads the vehicle slug from the route, looks up its configuration, and
 * renders a rich, scrollable view with imagery and key information.
 */
export default function VehicleDetail() {
  const navigate = useNavigate()
  const params = useParams()
  const slug = params.slug ?? ''
  const vehicle: DongfengVehicle | undefined = getDongfengVehicleBySlug(slug)

  if (!vehicle) {
    return (
      <motion.div
        className="space-y-6"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.35, ease: 'easeOut' }}
      >
        <AnimatedSection className="space-y-3">
          <h1 className="text-2xl font-semibold tracking-tight text-slate-900 md:text-3xl">
            Vehicle not found
          </h1>
          <p className="text-sm text-slate-600 md:text-base">
            The requested Dongfeng vehicle could not be found. It may have been
            moved or is not currently listed.
          </p>
          <button
            type="button"
            onClick={() => navigate(-1)}
            className="inline-flex items-center justify-center rounded-md bg-sky-700 px-4 py-2 text-sm font-semibold text-white shadow-sm transition hover:bg-sky-800 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500"
          >
            Go back
          </button>
        </AnimatedSection>
      </motion.div>
    )
  }

  return (
    <motion.div
      className="space-y-8 md:space-y-10"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.45, ease: 'easeOut' }}
    >
      <AnimatedSection className="space-y-4">
        <button
          type="button"
          onClick={() => navigate(-1)}
          className="text-xs font-semibold uppercase tracking-[0.18em] text-sky-700 transition hover:text-sky-900"
        >
          ← Back to vehicles
        </button>
        <div className="grid gap-6 md:grid-cols-[1.1fr,1fr] md:items-center">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.22em] text-sky-600">
              Dongfeng Vehicle
            </p>
            <h1 className="mt-2 text-2xl font-semibold tracking-tight text-slate-900 md:text-3xl">
              {vehicle.name}
            </h1>
            <p className="mt-1 text-xs font-medium uppercase tracking-[0.22em] text-slate-500">
              {vehicle.segment}
            </p>
            <p className="mt-3 text-sm leading-relaxed text-slate-600 md:text-base">
              {vehicle.overview}
            </p>
            <p className="mt-3 text-xs text-slate-600 md:text-sm">
              {vehicle.usage}
            </p>
          </div>

          {/* Larger full-view image of the car */}
          <div className="overflow-hidden rounded-2xl border border-slate-200 bg-slate-900/95 shadow-md">
            <div className="relative w-full h-64 sm:h-72 md:h-80 lg:h-96">
              <img
                src={vehicle.heroImage}
                alt={vehicle.name}
                className="absolute inset-0 h-full w-full object-contain"
              />
            </div>
          </div>
        </div>
      </AnimatedSection>

      <AnimatedSection
        delay={0.05}
        className="grid gap-6 md:grid-cols-[1.2fr,1fr] md:items-start"
      >
        <section className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
          <h2 className="text-sm font-semibold text-slate-900 md:text-base">
            Key points for commercial use
          </h2>
          <ul className="mt-3 space-y-2 text-xs text-slate-700 md:text-sm">
            {vehicle.detailBullets.map((item) => (
              <li key={item} className="flex gap-2">
                <span className="mt-[6px] inline-flex h-1.5 w-1.5 rounded-full bg-sky-600" />
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </section>

        <section className="rounded-xl border border-sky-100 bg-sky-50 p-5 text-xs text-slate-700 shadow-sm md:text-sm">
          <h2 className="text-sm font-semibold text-slate-900 md:text-base">
            Highlights at a glance
          </h2>
          <ul className="mt-3 space-y-2">
            {vehicle.highlights.map((highlight) => (
              <li key={highlight} className="flex gap-2">
                <span className="mt-[6px] inline-flex h-1.5 w-1.5 rounded-full bg-sky-600" />
                <span>{highlight}</span>
              </li>
            ))}
          </ul>
          {vehicle.notes && vehicle.notes.length > 0 && (
            <div className="mt-4 border-t border-sky-100 pt-3 text-[0.7rem] text-slate-600">
              {vehicle.notes.map((note) => (
                <p key={note} className="mt-1 first:mt-0">
                  {note}</p>
              ))}
            </div>
          )}
        </section>
      </AnimatedSection>
    </motion.div>
  )
}
