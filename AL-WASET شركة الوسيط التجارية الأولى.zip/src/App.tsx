/**
 * App.tsx
 * Root application component defining routes for AL-WASET First Commercial Company.
 */

import { HashRouter, Route, Routes } from 'react-router'
import { MainLayout } from './components/layout/MainLayout'
import HomePage from './pages/Home'
import AboutPage from './pages/About'
import ProductsPage from './pages/Products'
import ContactPage from './pages/Contact'
import VehicleDetailPage from './pages/VehicleDetail'

/**
 * App
 * Configures client-side routing and wraps pages with the shared layout.
 */
export default function App() {
  return (
    <HashRouter>
      <MainLayout>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/products" element={<ProductsPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/vehicles/:slug" element={<VehicleDetailPage />} />
        </Routes>
      </MainLayout>
    </HashRouter>
  )
}