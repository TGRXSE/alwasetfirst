/**
 * AnimatedSection.tsx
 * Reusable section wrapper that animates content into view on scroll.
 */

import type { ReactNode } from 'react'
import { motion } from 'motion/react'

/**
 * AnimatedSectionProps
 * Props for the AnimatedSection component.
 */
interface AnimatedSectionProps {
  /** Optional DOM id for anchoring and navigation. */
  id?: string
  /** Additional CSS classes for layout and styling. */
  className?: string
  /** Children to be rendered inside the animated section. */
  children: ReactNode
  /** Optional delay (in seconds) to stagger animations between sections. */
  delay?: number
}

/**
 * AnimatedSection
 * Fades and slides its children into view when they enter the viewport.
 */
export function AnimatedSection(props: AnimatedSectionProps) {
  const { id, className, children, delay = 0 } = props

  return (
    <motion.section
      id={id}
      className={className}
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.2 }}
      transition={{ duration: 0.6, ease: 'easeOut', delay }}
    >
      {children}
    </motion.section>
  )
}
