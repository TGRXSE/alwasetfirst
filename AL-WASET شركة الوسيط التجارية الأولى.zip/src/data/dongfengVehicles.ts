/**
 * dongfengVehicles.ts
 * Central configuration for Dongfeng vehicle data used across list and detail pages.
 */

export interface DongfengVehicle {
  /** URL-friendly identifier used for routing. */
  slug: string
  /** Marketing or model name of the vehicle. */
  name: string
  /** Segment label shown as a pill (e.g. Pickup, Light truck, SUV). */
  segment: string
  /** Short description shown in cards. */
  shortDescription: string
  /** Bullet highlights shown in cards. */
  highlights: string[]
  /** Primary hero image used on list and detail views. */
  heroImage: string
  /** Longer overview paragraph for the detail view. */
  overview: string
  /** Typical use cases or positioning description. */
  usage: string
  /** Additional bullet points for the detail view. */
  detailBullets: string[]
  /** Optional notes or disclaimers for the detail view. */
  notes?: string[]
}

/**
 * dongfengVehicles
 * Collection of Dongfeng vehicles displayed in the site.
 */
export const dongfengVehicles: DongfengVehicle[] = [
  {
    slug: 'dongfeng-rich-6',
    name: 'Dongfeng Rich 6',
    segment: 'Pickup',
    shortDescription:
      'A versatile double-cabin pickup suitable for commercial fleets and mixed city/off-road use.',
    highlights: [
      'Diesel engine options tailored for cost-conscious fleet operations.',
      'Configurable bed setups for tools, light cargo, and utility equipment.',
      'Balanced comfort and durability for everyday business use.',
    ],
    heroImage:
      'https://pub-cdn.sider.ai/u/U0Z6H6YZE20/web-coder/697e357acabc5f0ad8729716/resource/03b36a0b-f815-41cf-b09e-a4e39b6863fa.webp',
    overview:
      'The Rich 6 is designed for operators who need a capable work vehicle that can still move comfortably in urban environments. It can be configured with different bed liners, covers, and towing setups to match specific business requirements.',
    usage:
      'Typical applications include construction support, utilities, and field service operations where both people and equipment must be transported reliably.',
    detailBullets: [
      'Suitable for construction support, utilities, and field service teams.',
      'Optional accessories for cargo protection and tool organization.',
      'Engine and drivetrain options may vary by market regulations.',
    ],
    notes: [
      'Final specifications and available configurations may vary by country and distributor.',
    ],
  },
  {
    slug: 'dongfeng-captain',
    name: 'Dongfeng Captain',
    segment: 'Light truck',
    shortDescription:
      'Compact light-duty truck designed for urban and regional distribution routes.',
    highlights: [
      'Optimized for last-mile and city-center delivery operations.',
      'Cab and chassis configurations to match different body requirements.',
      'Designed for stable performance and predictable operating costs.',
    ],
    heroImage:
      'https://pub-cdn.sider.ai/u/U0Z6H6YZE20/web-coder/697e357acabc5f0ad8729716/resource/fdbadafb-9e3e-45ad-9e42-a82fd3987cf5.jpg',
    overview:
      'The Captain series is typically used for distribution fleets that require reliable uptime and easy maneuvering in narrow streets. Bodies can be adapted for dry cargo, refrigerated transport, or specialized applications.',
    usage:
      'Well-suited for FMCG, e-commerce, and regional delivery operations that need dependable transport with controlled operating costs.',
    detailBullets: [
      'Multiple wheelbase and payload configurations, depending on market.',
      'Cab ergonomics focused on driver comfort and visibility.',
      'Body options for dry box, refrigerated, and specialized logistics uses.',
    ],
    notes: [
      'Body and payload configurations are subject to local regulations and approvals.',
    ],
  },
  {
    slug: 'dongfeng-t5',
    name: 'Dongfeng T5',
    segment: 'SUV',
    shortDescription:
      'Passenger SUV for corporate transport, management fleets, and executive mobility.',
    highlights: [
      'Comfortable interior for staff and executive transportation.',
      'Modern safety and driver-assistance features depending on specification.',
      'Suitable for mixed highway and city driving conditions.',
    ],
    heroImage:
      'https://pub-cdn.sider.ai/u/U0Z6H6YZE20/web-coder/697e357acabc5f0ad8729716/resource/d18dd78b-35fd-4126-a793-3058f54b8c68.jpeg',
    overview:
      'The T5 is often positioned as a corporate and executive transport solution, offering a more refined ride for management teams and visiting partners. Interior trim and equipment levels can be tailored to comfort and image requirements.',
    usage:
      'Commonly used as part of company fleets for management, visiting partners, and VIP shuttle services.',
    detailBullets: [
      'Spacious cabin with seating layouts suitable for company drivers.',
      'Optional technology packages depending on regional availability.',
      'Can be branded with corporate identity for VIP shuttle services.',
    ],
    notes: [
      'Feature availability (such as safety and technology packages) depends on local market specifications.',
    ],
  },
]

/**
 * getDongfengVehicleBySlug
 * Looks up a Dongfeng vehicle configuration from its slug.
 */
export function getDongfengVehicleBySlug(slug: string): DongfengVehicle | undefined {
  return dongfengVehicles.find((vehicle) => vehicle.slug === slug)
}